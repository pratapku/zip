from django.apps import AppConfig


class CovinAppConfig(AppConfig):
    name = 'covin_app'
